#include "dynamic.c"

int main()
{
    free(NULL);
    return 0;
}
